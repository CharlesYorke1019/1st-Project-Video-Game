import pygame
import sys

from pygame import K_COMMA, K_LSHIFT, K_PERIOD, K_RETURN, K_RSHIFT, K_SEMICOLON, KEYDOWN, MOUSEBUTTONDOWN, K_q, K_x, image, key, sprite
from pygame.constants import KEYUP, K_z

from support import import_folder

pygame.init()

screen_width = 1200
screen_height = 704
screen = pygame.display.set_mode((screen_width, screen_height))
clock = pygame.time.Clock()

fire_ball = pygame.image.load('/Users/charlieyorke/ace/imgs/fireball.png')
fire_ball_rect = fire_ball.get_rect(topleft=(700, 650))

flip_fire_ball = pygame.transform.flip(fire_ball, True, False)
flip_fire_ball_rect = flip_fire_ball.get_rect(topleft=(700, 650))

rasengan = pygame.image.load('/Users/charlieyorke/ace/imgs/rasengan.png')
rasengan_rect = rasengan.get_rect(topleft=(700, 650))

flip_rasengan = pygame.transform.flip(rasengan, True, False)
flip_rasengan_rect = flip_rasengan.get_rect(topleft=(700, 650))

background = pygame.image.load('/Users/charlieyorke/ace/imgs/BG1.png')
background2 = pygame.image.load('/Users/charlieyorke/ace/imgs/BG2.png')

start_image = pygame.image.load('/Users/charlieyorke/ace/imgs/startlogo.png')
settings_image = pygame.image.load('/Users/charlieyorke/ace/imgs/settingslogo.png')
exit_image = pygame.image.load('/Users/charlieyorke/ace/imgs/exitlogo.png')
back_image = pygame.image.load('/Users/charlieyorke/ace/imgs/backlogo.png')
pause_image = pygame.image.load('/Users/charlieyorke/ace/imgs/pauselogo.png')
menu_image = pygame.image.load('/Users/charlieyorke/ace/imgs/menulogo.png')
return_image = pygame.image.load('/Users/charlieyorke/ace/imgs/returnlogo.png')
startagain = pygame.image.load('/Users/charlieyorke/ace/imgs/startagain.png')
fight_symobl = pygame.image.load('/Users/charlieyorke/ace/imgs/fight.png')
menu = pygame.image.load('/Users/charlieyorke/ace/imgs/menu.png')
map_select_screen = pygame.image.load('/Users/charlieyorke/ace/imgs/selectmap.png')
mp1 = pygame.image.load('/Users/charlieyorke/ace/imgs/map1.png')
mp2 = pygame.image.load('/Users/charlieyorke/ace/imgs/map2.png')

class Player(pygame.sprite.Sprite):
    def __init__(self, name, pos):
        pygame.sprite.Sprite.__init__(self)
        self.import_character_assets()
        self.name = name
        self.frame_index = 0
        self.animation_speed = 0.12
        self.image = self.animations['idle'][self.frame_index]
        self.rect = self.image.get_rect(topleft = pos)

        self.direction = pygame.math.Vector2(0, 0)
        self.speed = 10
        self.gravity = 1.2
        self.jump_speed = -25

        self.status = 'idle'
        self.facing_right = True
        self.on_ground = True
        self.on_ceiling = False
        self.is_jumping = False

        self.max_health = 320

        self.on_screen = True

        self.combo1 = False
        self.combo2 = False

        self.level = 1
        self.charge = 0

        self.count = 0
        self.count2 = 0

        self.teleporting = False

        self.hit_fireball = False
        self.hit_chidori = False

        self.hit1 = True
        self.hit2 = True

        self.spamcount1 = 0 
        self.spamcount2 = 0

        self.attack1count = 0
        self.attack1stall = False
        self.attack1right = False
        self.attack1 = False

        self.keepattack = False

        self.hitcount = 0

        self.rcount1 = 0

    def import_character_assets(self):
        character_path = '/Users/charlieyorke/ace/imgs/Naruto/'
        self.animations = {'idle': [], 'run': [], 'jump': [], 'attack1': [], 'attack1after': [], 'attack2': [], 'charge': [], 'combo': [], 'comboscene1': [], 'comboscene2': [], 'comboscene3': [], 'combo2': [], 'combo2scene1': [], 'combo2scene2': [], 'combo2scene3': [], 'teleport': [], 'guard': [], 'guardattack2': [], 'hitfireball': [], 'hitchidori': []}

        for animation in self.animations.keys():
            full_path = character_path + animation
            self.animations[animation] = import_folder(full_path)

    def animate(self):
        animation = self.animations[self.status]

        # loop over frame index
        self.frame_index += self.animation_speed
        if self.frame_index >= len(animation):
            self.frame_index = 0

        image = animation[int(self.frame_index)]
        if self.facing_right:
            self.image = image
        else:
            flipped_image = pygame.transform.flip(image, True, False)
            self.image = flipped_image

        if self.on_ceiling:
            self.rect = self.image.get_rect(bottom = self.rect.bottom)
        elif self.on_ceiling:
            self.rect = self.image.get_rect(midtop = self.rect.midtop)
        else:
            self.rect = self.image.get_rect(center = self.rect.center)

    def get_input(self):
        keys = pygame.key.get_pressed()

        if keys[pygame.K_d] and self.rect.x < 1150:
            self.direction.x = 1
            self.facing_right = True
            
        elif keys[pygame.K_a] and self.rect.x > 1:
            self.direction.x = -1
            self.facing_right = False
        
        else:
            self.direction.x = 0

        if keys[pygame.K_w] and self.on_ground == True:
            if self.rect.bottom <= 698:
                self.on_ground = False
                self.is_jumping = True
                self.jump()

    def get_status(self):

        keys = pygame.key.get_pressed()

        if self.direction.y < 0:
            self.status = 'jump'
            self.animation_speed = .20
        
        else:
            if self.direction.x != 0:
                self.status = 'run'
                self.animation_speed = .20
            else:
                self.status = 'idle'
                self.animation_speed = .20

        if self.hit1 == True:

            if keys[pygame.K_z]:
                self.status = 'combo'
                self.animation_speed = .10
                if self.on_ground == True:
                    self.direction.y = 0
                self.spamcount1 += 1
                print(self.spamcount1)
            if self.spamcount1 in range(31, 250) and self.status == 'combo':
                self.hit1 = False
                self.spamcount1 = 0
            if not keys[pygame.K_z]:
                self.hit1 = True

        if self.count in range(151, 179) and self.level == 1:
            self.combo1 = False
            self.count = 0
        if keys[pygame.K_z]:
            if self.combo1 == True and self.level == 1:
                self.status = 'comboscene1'
                self.animation_speed = 0.22
                self.direction.x = 0
                self.count += 1
                print(self.count)
                self.hit1 = False
                if self.on_ground == False:
                    self.direction.y = 0
        if not keys[pygame.K_z]:
            self.count = 0
            self.hit1 = True

        if self.count in range(217, 250) and self.level == 2:
            self.combo1 = False
            self.count = 0  
        if keys[pygame.K_z]: 
            if self.combo1 == True and self.level == 2:
                self.status = 'comboscene2'
                self.animation_speed = 0.19
                self.direction.x = 0 
                self.count += 1
                #print(self.count)
                self.hit1 = False
        if not keys[pygame.K_z]:
            self.count = 0
            self.hit1 = True

        if self.count in range(162, 250) and self.level == 3:
            self.combo1 = False
            self.count = 0
        if keys[pygame.K_z]:
            if self.combo1 == True and self.level == 3:
                self.status = 'comboscene3'
                self.animation_speed = 0.25
                self.direction.x = 0
                if self.on_ground == True:
                    self.direction.y = 0
                self.count += 1
                #print(self.count)
                self.hit1 = False
        if not keys[pygame.K_z]:
            self.count = 0
            self.hit1 = True

        if self.hit2 == True:

            if keys[pygame.K_LSHIFT] and not keys[pygame.K_z]:
                self.status = 'combo2'
                self.animation_speed = 0.15
                if self.on_ground == True:
                    self.direction.y = 0
                self.spamcount2 += 1
                #print(self.spamcount2)
            if self.spamcount2 in range(23, 150) and self.status == 'combo2':
                self.hit2 = False
                self.spamcount2 = 0
            if not keys[pygame.K_LSHIFT]:
                self.hit2 = True

        if self.count2 in range(231, 300) and self.level == 1:
            self.combo2 = False
            self.count2 = 0
        if keys[pygame.K_LSHIFT]: 
            if self.combo2 == True and self.level == 1:
                self.status = 'combo2scene1'
                self.animation_speed = 0.18
                self.direction.x = 0
                if self.on_ground == True:
                    self.direction.y = 0
                self.count2 += 1
                print(self.count2)
                self.hit2 = False
        if not keys[pygame.K_LSHIFT]:
            self.count2 = 0
            self.hit2 = True

        if self.count2 in range(73, 100) and self.level == 2:
            self.combo2 = False
            self.count2 = 0 
        if keys[pygame.K_LSHIFT]: 
            if self.combo2 == True and self.level == 2:
                self.status = 'combo2scene2'
                self.animation_speed = 0.67
                self.direction.x = 0
                if self.on_ground == True:
                    self.direction.y = 0
                self.count2 += 1
                #print(self.count2)
                self.hit2 = False
        if not keys[pygame.K_LSHIFT]:
            self.count2 = 0
            self.hit2 = True

        if self.count2 in range(187, 250) and self.level == 3:
            self.combo2 = False
            self.count2 = 0
        if keys[pygame.K_LSHIFT]:
            if self.combo2 == True and self.level == 3:
                self.status = 'combo2scene3'
                self.animation_speed = 0.25
                self.direction.x = 0
                if self.on_ground == True:
                    self.direction.y = 0
                self.count2 += 1
                print(self.count2)
                self.hit2 = False
        if not keys[pygame.K_LSHIFT]:
            self.count2 = 0
            self.hit2 = True

        if keys[pygame.K_x]:
            if self.combo1 == False and self.combo2 == False:
                self.status = 'attack1'
                self.animation_speed = 0.15
                self.direction.x = 0 
                if self.on_ground == True:
                    self.direction.y = 0
                self.attack1count += 1
                print(self.attack1count)
        if self.attack1count in range(43, 100) and keys[pygame.K_x]:
            self.attack1stall = True
        if not keys[pygame.K_x]:
            self.attack1stall = False
            self.attack1count = 0

        if self.attack1stall == True:
            self.status = 'attack1after'
            self.animation_speed = 0.05
            self.direction.x = 0
            self.attack1count = 0

        if keys[pygame.K_c]:
            if self.combo1 == False and self.combo2 == False:
                self.status = 'attack2'
                self.animation_speed = 0.20
                self.direction.x = 0
                if self.on_ground == True:
                    self.direction.y = 0

        if keys[pygame.K_s]:
            if self.combo1 == False and self.combo2 == False:
                self.status = 'charge'
                self.animation_speed = .45
                self.direction.x = 0
                if self.on_ground == True:
                    self.direction.y = 0
                self.charge += 1
                #print(self.charge)

        if keys[pygame.K_q]:
            self.status = 'teleport'
            self.animation_speed = .05
            self.teleporting = True
            if self.on_ground == True:
                self.direction.y = 0

        if keys[pygame.K_e]:
            self.status = 'guard'
            self.animation_speed = .10
            self.direction.x = 0
            if self.on_ground == True:
                self.direction.y = 0

        if self.hit_fireball == True:
            self.status = 'hitfireball'
            self.speed = 0
            self.animation_speed = 0.75
            if self.on_ground == True:
                self.direction.y = 0
        if self.hit_fireball == False:
            self.speed = 10

        if self.hit_chidori == True:
            self.status = 'hitchidori'
            self.speed = 0
            self.animation_speed = 0.20
            if self.on_ground == True:
                self.direction.y = 0
        if self.hit_chidori == False:
            self.speed = 10

    def comboscenes(self):

        if self.combo1 == True:
            self.combo2 == False
        if self.combo2 == True:
            self.combo1 == False
        
    def apply_gravity(self):
        if self.on_ground == False:
            self.direction.y += self.gravity
            self.rect.y += self.direction.y

    def jump(self):
        self.direction.y = self.jump_speed

    def super_charge(self):
        if self.charge >= 234 and self.level == 1:
            self.charge = 0
            self.level += 1
            print(self.level)
        if self.charge >= 234 and self.level == 2:
            self.charge = 0
            self.level += 1
        if self.charge >= 234 and self.level == 3:
            self.charge = 0
            self.level -= 2
            print(self.level)

    def health(self, damage):
        self.damage = damage
        if self.max_health > 0: 
            if self.status == 'attack':
                self.max_health += 0
            if self.status == 'attack2':
                self.max_health += 0
            if self.status == 'guardattack2':
                self.max_health += 0
            else:
                self.max_health -= self.damage

    def update(self):
        self.get_input()
        self.get_status()
        self.animate()

        self.super_charge()

        self.comboscenes()

class Player2(pygame.sprite.Sprite):
    def __init__(self, name, pos):
        pygame.sprite.Sprite.__init__(self)
        self.import_character_assets()
        self.name = name
        self.frame_index = 0
        self.animation_speed = 0.12
        self.image = self.animations['idle'][self.frame_index]
        self.rect = self.image.get_rect(topleft = pos)

        self.direction = pygame.math.Vector2(0, 0)
        self.speed = 10
        self.gravity = 1.2
        self.jump_speed = -25

        self.status = 'idle'
        self.facing_right = False
        self.running = False
        self.on_ground = True
        self.on_ceiling = False
        self.on_right = False
        self.on_left = False

        self.max_health = 1

        self.on_screen = True

        self.combo1 = False
        self.combo2 = False

        self.attack2 = False
        self.attack2right = False

        self.attack1 = True

        self.gethit = False

        self.level = 1
        self.charge = 234

        self.count = 0
        self.count2 = 0
        
        self.spamcount1 = 0
        self.spamcount2 = 0

        self.teleporting = False    

        self.hit_rasengan = False
        self.hit_rasenshuriken = False 

        self.hit1 = True
        self.hit2 = True

        self.hitcount = 0

        self.attack1count = 0

    def import_character_assets(self):
        character_path = '/Users/charlieyorke/ace/imgs/Sasuke/'
        self.animations = {'idle': [], 'run': [], 'jump': [], 'attack1': [], 'attack2': [], 'charge': [], 'flinch': [], 'combo': [], 'comboscene1': [], 'comboscene2': [], 'comboscene3': [], 'combo2': [], 'combo2scene1': [], 'combo2scene2': [], 'combo2scene3': [], 'guard': [], 'teleport': [], 'hitrasengan': []}

        for animation in self.animations.keys():
            full_path = character_path + animation
            self.animations[animation] = import_folder(full_path)

    def animate(self):
        animation = self.animations[self.status]

        # loop over frame index
        self.frame_index += self.animation_speed
        if self.frame_index >= len(animation):
            self.frame_index = 0

        image = animation[int(self.frame_index)]
        if self.facing_right:
            self.image = image
        else:
            flipped_image = pygame.transform.flip(image, True, False)
            self.image = flipped_image

        if self.on_ceiling:
            self.rect = self.image.get_rect(bottom = self.rect.bottom)
        elif self.on_ceiling:
            self.rect = self.image.get_rect(midtop = self.rect.midtop)
        else:
            self.rect = self.image.get_rect(center = self.rect.center)
    
    def get_input(self):
        keys = pygame.key.get_pressed()

        if keys[pygame.K_RIGHT] and self.rect.x < 1150:
            self.direction.x = 1
            self.facing_right = True

        elif keys[pygame.K_LEFT] and self.rect.x > 1:
            self.direction.x = -1
            self.facing_right = False
        
        else:
            self.direction.x = 0
        

        if keys[pygame.K_UP] and self.on_ground == True:
            if self.rect.bottom <= 698:
                self.on_ground = False
                self.jump()

    def get_status(self):

        keys = pygame.key.get_pressed()

        if self.direction.y < 0:
            self.status = 'jump'
            self.animation_speed = .20
        
        else:
            if self.direction.x != 0:
                self.status = 'run'
                self.animation_speed = .20
            else:
                self.status = 'idle'
                self.animation_speed = .20

        if self.gethit == True:
            self.status = 'flinch'
            self.animation_speed = 0.15
            self.direction.y = 0

        if self.hit1 == True:

            if keys[pygame.K_RSHIFT]:
                self.status = 'combo'
                self.animation_speed = 0.10
                if self.on_ground == True:
                    self.direction.y = 0
                self.spamcount1 += 1
                #print(self.spamcount1)
            if self.spamcount1 in range(28, 100) and self.status == 'combo':
                self.hit1 = False
                self.spamcount1 = 0
            if not keys[pygame.K_RSHIFT]: 
                self.hit1 = True

        if self.count in range(149, 175) and self.level == 1:
            self.count = 0
            self.combo1 = False
        if keys[pygame.K_RSHIFT]: 
            if self.combo1 == True and self.level == 1:
                self.status = 'comboscene1'
                self.animation_speed = 0.22
                self.direction.x = 0
                if self.on_ground == True:
                    self.direction.y = 0
                self.count += 1
                #print(self.count)
                self.hit1 = False
        if not keys[pygame.K_RSHIFT]:
            self.count = 0
            self.hit1 = True

        if self.count in range(248, 300) and self.level == 2:
            self.count = 0
            self.combo1 = False
        if keys[pygame.K_RSHIFT]: 
            if self.combo1 == True and self.level == 2:
                self.status = 'comboscene2'
                self.animation_speed = 0.17
                self.direction.x = 0
                if self.on_ground == True:
                    self.direction.y = 0
                self.count += 1
                #print(self.count)
                self.hit1 = False
        if not keys[pygame.K_RSHIFT]:
            self.count = 0
            self.hit1 = True
                
        if self.count in range(199, 250) and self.level == 3:
            self.count = 0
            self.combo1 = False
        if keys[pygame.K_RSHIFT]:
            if self.combo1 == True and self.level == 3:
                self.status = 'comboscene3'
                self.animation_speed = 0.23
                self.direction.x = 0
                if self.on_ground == True:
                    self.direction.y = 0 
                self.count += 1
                #print(self.count)
        if not keys[pygame.K_RSHIFT]:
            self.count = 0
            self.hit1 = True

        if self.hit2 == True:
            if keys[pygame.K_RETURN] and not keys[pygame.K_RSHIFT]:
                self.status = 'combo2'
                self.animation_speed = 0.15
                if self.on_ground == True:
                    self.direction.y = 0
                self.spamcount2 += 1
                #print(self.spamcount2)
            if self.spamcount2 in range(26, 100) and self.status == 'combo2':
                self.hit2 = False
                self.spamcount2 = 0 
            if not keys[pygame.K_RETURN]:
                self.hit2 = True

        if self.count2 in range(148, 175) and self.level == 1:
            self.count2 = 0
            self.combo2 = False
        if keys[pygame.K_RETURN]: 
            if self.combo2 == True and self.level == 1:
                self.status = 'combo2scene1'
                self.animation_speed = 0.23
                self.direction.x = 0
                if self.on_ground == True:
                    self.direction.y = 0
                self.count2 += 1
                #print(self.count2) 
                self.hit2 = False  
        if not keys[pygame.K_RETURN]:
            self.count2 = 0
            self.hit2 = True

        if self.count2 in range(188, 250) and self.level == 2:
            self.count2 = 0
            self.combo2 = False
        if keys[pygame.K_RETURN]:
            if self.combo2 == True and self.level == 2:
                self.status = 'combo2scene2'
                self.animation_speed = 0.24
                self.direction.x = 0
                if self.on_ground == True:
                    self.direction.y = 0
                self.count2 += 1
                #print(self.count2)
                self.hit2 = False
        if not keys[pygame.K_RETURN]:
            self.count2 = 0
            self.hit2 = True

        if self.count2 in range(197, 250) and self.level == 3:
            self.count2 = 0
            self.combo2 = False
        if keys[pygame.K_RETURN]:
            if self.combo2 == True and self.level == 3:
                self.status = 'combo2scene3'
                self.animation_speed = 0.23
                self.direction.x = 0
                if self.on_ground == True:
                    self.direction.y = 0
                self.count2 += 1
                print(self.count2)
                self.hit2 = False
        if not keys[pygame.K_RETURN]:
            self.count2 = 0
            self.hit2 = True

        if self.attack1 == True:

            if keys[pygame.K_SLASH]:

                self.status = 'attack1'
                self.animation_speed = 0.20
                if self.on_ground == True:
                    self.direction.y = 0
                if self.on_ground == False:
                    self.direction.y = -1
                self.attack1count += 1
                print(self.attack1count)
                if self.attack1count in range(47, 100):
                    self.attack1 = False
                    self.attack1count = 0
        if not keys[pygame.K_SLASH]:
            self.attack1count = 0
            self.attack1 = True

        #if keys[pygame.K_SLASH]:
            #self.attack1 = True
        #if not keys[pygame.K_SLASH]:
            #self.attack1 = False

        #if self.attack1count in range(50, 70) and self.attack1 == True:
            #self.attack1 = False
        #if self.attack1 == True:
            #self.status = 'attack1'
            #self.animation_speed = 0.20
            #if self.on_ground == True:
                #self.direction.y = 0
           # self.attack1count += 1
           # print(self.attack1count)
        #if self.attack1 == False:
            #self.attack1count = 0

        if keys[pygame.K_PERIOD]:
            self.status = 'attack2'
            self.animation_speed = 0.30
            if self.on_ground == True:
                self.direction.y = 0

        if keys[pygame.K_DOWN]:
            self.status = 'charge'
            self.animation_speed = .45
            self.direction.x = 0
            if self.on_ground == True:
                self.direction.y = 0
            self.charge -= 1
            #print(self.charge)

        if keys[pygame.K_COMMA]:
            self.status = 'teleport'
            self.animation_speed = 0.10
            self.teleporting = True
            if self.on_ground == True:
                self.direction.y = 0

        if keys[pygame.K_SEMICOLON]:
            self.status = 'guard'
            self.animation_speed = 0.10
            self.direction.x = 0
            if self.on_ground == True:
                self.direction.y = 0

        if self.hit_rasengan == True:
            self.status = 'hitrasengan'
            self.speed = 0
            self.animation_speed = 0.20
            if self.on_ground == True:
                self.direction.y = 0
        if self.hit_rasengan == False:
            self.speed = 10

    def apply_gravity(self):
        if self.on_ground == False:
            self.direction.y += self.gravity
            self.rect.y += self.direction.y
        
    def jump(self):
        self.direction.y = self.jump_speed

    def super_charge(self):
        if self.charge <= 0 and self.level == 1:
            self.charge = 234
            self.level += 1
            print(self.level)
        if self.charge <= 0 and self.level == 2:
            self.charge = 234
            self.level += 1
        if self.charge <= 0 and self.level == 3:
            self.charge = 234
            self.level -= 2
            print(self.level)
        
    def health(self, damage):
        self.damage = damage
        if self.max_health < 321:
            if self.status == 'attack':
                self.max_health += 0
            if self.status == 'attack2':
                self.max_health += 0
            else:
                self.max_health += self.damage

    def update(self):
        self.get_input()
        self.get_status()
        self.animate()

        self.super_charge()

class Level:
    def __init__(self, surface):
        # level setup
        self.display_surface = surface
        self.setup_level()
        self.world_shift = 0
        self.running = True
        self.p1_winner = False
        self.p2_winner = False
        self.gameover = False
        self.map1 = False
        self.map2 = False

    def setup_level(self):
        n_x = 100
        n_y = 640

        s_x = 1050
        s_y = 640
        #print(y)

        self.player = pygame.sprite.GroupSingle()
        self.player2 = pygame.sprite.GroupSingle()
       
        player_sprite = Player('Naruto', (n_x, n_y))
        player2_sprite = Player2('Sasuke', (s_x, s_y))
        
        self.player.add(player_sprite)
        self.player2.add(player2_sprite)

    def horizontal_movement_collision(self):
        player = self.player.sprite
        player.rect.x += player.direction.x * player.speed

        player2 = self.player2.sprite
        player2.rect.x += player2.direction.x * player2.speed

    def vertical_movement_collision(self):
        player = self.player.sprite
        player2 = self.player2.sprite

        #print(player.rect.bottom)

        #### PLAYER 1 ####
        if player.direction.y == 0:
            player.on_ground = True
            player.rect.bottom = 698

        elif player.rect.bottom <= 698:
            player.apply_gravity()
        
        else:
            player.on_ground = True
            player.rect.bottom = 698
            #player.direction.y = 0

        #### PLAYER 2 ####
        if player2.direction.y == 0:
            player2.on_ground = True
            player2.rect.bottom = 698

        elif player2.rect.bottom <= 698:
            player2.apply_gravity()
        
        else:
            player2.on_ground = True
            player2.rect.bottom = 698

    def test(self):
        player = self.player.sprite
        player2 = self.player2.sprite

        keys = pygame.key.get_pressed()

        # player 1 combo
        ################################################ 
        
        if pygame.sprite.collide_mask(player, player2):
            if keys[pygame.K_z]:
                player.combo1 = True
        else:
            if not keys[pygame.K_z]:
                player.combo1 = False
        
        if pygame.sprite.collide_mask(player2, player):
            if player.combo1 == True:
                player2.on_screen = False
            else:
                player2.on_screen = True

        if not pygame.sprite.collide_mask(player, player2):
            if player.combo1 == False:
                player2.on_screen = True
            else:
                player2.on_screen = False

        # player 1 kickcombo
        ################################################ 

        if player.combo1 == False:
            if pygame.sprite.collide_mask(player, player2):
                if keys[pygame.K_LSHIFT]:
                    player.combo2 = True
            else:
                if not keys[pygame.K_LSHIFT]:
                    player.combo2 = False

            if pygame.sprite.collide_mask(player, player2):
                if player.combo2 == True:
                    player2.on_screen = False
                else:
                    player2.on_screen = True

            if not pygame.sprite.collide_mask(player, player2):
                if player.combo2 == False:
                    player2.on_screen = True
                else:
                    player2.on_screen = False
                
        # player 2 combo
        ################################################       

        if pygame.sprite.collide_mask(player2, player):
            if keys[pygame.K_RSHIFT]:
                player2.combo1 = True
        else:
            if not keys[pygame.K_RSHIFT]:
                player2.combo1 = False

        if pygame.sprite.collide_mask(player2, player):
            if player2.combo1 == True:
                player.on_screen = False
            else:
                player.on_screen = True
        
        if not pygame.sprite.collide_mask(player2, player):
            if player2.combo1 == False:
                player.on_screen = True
            else:
                player.on_screen = False

        # player 2 kick combo
        ################################################         

        if player2.combo1 == False:
            if pygame.sprite.collide_mask(player, player2):
                if keys[pygame.K_RETURN]:
                    player2.combo2 = True
            else:
                if not keys[pygame.K_RETURN]:
                    player2.combo2 = False

            if pygame.sprite.collide_mask(player, player2):
                if player2.combo2 == True:
                    player.on_screen = False
                else:
                    player.on_screen = True

            if not pygame.sprite.collide_mask(player, player2):
                if player2.combo2 == False:
                    player.on_screen = True
                else:
                    player.on_screen = False

        ################################################ 

        if pygame.sprite.collide_mask(player, player2):
            if keys[pygame.K_z] and keys[pygame.K_PERIOD]:
                player.combo1 = False
                player2.on_screen = True

        ################################################ 

        if pygame.sprite.collide_mask(player, player2):
            if keys[pygame.K_e] and keys[pygame.K_RSHIFT]:
                player2.combo1 = False
                player.on_screen = True

        if pygame.sprite.collide_mask(player, player2):
            if keys[pygame.K_e] and keys[pygame.K_RETURN]:
                player2.combo2 = False
                player.on_screen = True

        ################################################ 

        if pygame.sprite.collide_mask(player, player2):
            if keys[pygame.K_SEMICOLON] and keys[pygame.K_z]:
                player.combo1 = False
                player2.on_screen = True

        if pygame.sprite.collide_mask(player, player2):
            if keys[pygame.K_SEMICOLON] and keys[pygame.K_LSHIFT]:
                player.combo2 = False
                player2.on_screen = True

        ################################################ 

        if pygame.sprite.collide_mask(player, player2):
            if keys[pygame.K_PERIOD]:
                player.guardattack2 = True
        else:
            player.guardattack2 = False
        if not pygame.sprite.collide_mask(player, player2):
            if not keys[pygame.K_PERIOD]:
                player.guardattack2 = False

        ################################################

        if player2.on_screen == False:
            player2.speed = 0
        if player2.on_screen == True:
            player2.speed = 10

        if player.on_screen == False:
            player.speed = 0 
        if player.on_screen == True:
            player.speed = 10

    def adding_attacks(self):
        player = self.player.sprite
        player2 = self.player2.sprite

        keys = pygame.key.get_pressed()

        #### PLAYER 2 ####

        if keys[pygame.K_PERIOD] and player2.facing_right == False:

            player2.attack2 = True

        if keys[pygame.K_PERIOD] and player2.facing_right == True:

            player2.attack2right = True

        if player2.attack2 == True:

            screen.blit(fire_ball, (fire_ball_rect))
           
            fire_ball_rect.x -= 20

        if player2.attack2 == False:

            fire_ball_rect.topleft = (player2.rect.x - 10, player2.rect.y + 10)

        if player2.attack2right == True:
            
            screen.blit(flip_fire_ball, (flip_fire_ball_rect))

            flip_fire_ball_rect.x += 20

        if player2.attack2right == False:

            flip_fire_ball_rect.topleft = (player2.rect.x + 20, player2.rect.y + 10)

        #### PLAYER 1 ####

        if player.attack1stall == True:

            if keys[pygame.K_x] and player.facing_right == False:

                player.attack1 = True

            if keys[pygame.K_x] and player.facing_right == True:

                player.attack1right = True

            if player.attack1 == True:

                screen.blit(rasengan, (rasengan_rect))

                rasengan_rect.x -= 20

            if player.attack1 == False:

                rasengan_rect.topleft = (player.rect.x, player.rect.y)

            if player.attack1right == True:

                screen.blit(flip_rasengan, (flip_rasengan_rect))

                flip_rasengan_rect.x += 20

            if player.attack1right == False:

                flip_rasengan_rect.topleft = (player.rect.x + 55, player.rect.y + 15)

        if player.attack1stall == False:

            rasengan_rect.topleft = (player.rect.x, player.rect.y)

            flip_rasengan_rect.topleft = (player.rect.x + 55, player.rect.y + 35)

    def collisions(self):
        player = self.player.sprite
        player2 = self.player2.sprite

        keys = pygame.key.get_pressed()

        if pygame.sprite.collide_mask(player, player2) and keys[pygame.K_PERIOD] and player.status != 'guardattack2' and player.status != 'guard' and player.status != 'teleport':
            player.hit_fireball = True

            player.health(25)

        else:
            player.hit_fireball = False


        if pygame.sprite.collide_mask(player, player2) and player2.status == 'attack1':
            player.hit_chidori = True

        else:
            player.hit_chidori = False


        if pygame.sprite.collide_mask(player, player2) and keys[pygame.K_x]:
            player2.hit_rasengan = True

        else:
            player2.hit_rasengan = False

    def test_collisions(self):
        player = self.player.sprite
        player2 = self.player2.sprite

        keys = pygame.key.get_pressed()

        if pygame.Rect.colliderect(player.rect, fire_ball_rect) and player2.attack2 == True:
            player2.attack2 = False
            fire_ball_rect.topleft = (player2.rect.x - 10, player2.rect.y + 40)
            player.hit_fireball = True
            player.health(10)
            player.rect.x -= 5

        if pygame.Rect.colliderect(player.rect, flip_fire_ball_rect) and player2.attack2right == True:
            player2.attack2right = False
            flip_fire_ball_rect.topleft = (player2.rect.x + 20, player2.rect.y + 40)
            player.hit_fireball = True
            player.health(10)

        if fire_ball_rect.x < 10:
            player2.attack2 = False

        if flip_fire_ball_rect.x > 1150:
            player2.attack2right = False

        if pygame.Rect.colliderect(player2.rect, rasengan_rect) and player.attack1 == True:
            player.attack1 = False
            rasengan_rect.topleft = (player.rect.x + 20, player.rect.y + 10) 
            player2.rect.x -= 5

        if pygame.Rect.colliderect(player2.rect, flip_rasengan_rect) and player.attack1right == True:
            player.attack1right = False
            flip_rasengan_rect.topleft = (player.rect.x + 55, player.rect.y + 35)
            player2.rect.x += 5
            player.attack1stall = False

        if rasengan_rect.x < 10:
            player.attack1 = False
            
        if flip_rasengan_rect.x > 1150:
            player.attack1right = False
            player.attack1stall = False
        
    def positioning(self):
        player = self.player.sprite
        player2 = self.player2.sprite

        keys = pygame.key.get_pressed()

        for event in pygame.event.get():
            if player.teleporting == True:
                if event.type == KEYUP and event.key == K_q:
                    if player.facing_right == True:
                        player.rect.x += 140
                    if player.facing_right == False:
                        player.rect.x -= 140

            if player2.teleporting == True:
                if event.type == KEYUP and event.key == K_COMMA:
                    if player2.facing_right == True:
                        player2.rect.x += 150
                    if player2.facing_right == False:
                        player2.rect.x -= 150

            if player2.combo1 == True:
                if event.type == KEYUP and event.key == K_RSHIFT:
                    if player2.facing_right == False:
                        player.rect.x = player2.rect.x + 100

        if player2.attack1 == True:
            if player2.attack1count in range(46, 100):
                if player2.facing_right == False:
                    player2.rect.x -= 150
                if player2.facing_right == True:
                    player2.rect.x += 150

        #### PLAYER 1 ATTACKS ####

        if player.count in range(150, 179) and player.level == 1:
            if player.facing_right == True:
                player2.rect.x += 210
                player.rect.x += 26.5
            if player.facing_right == False:
                player2.rect.x -= 210
                player.rect.x -= 26.5

        if player.count2 in range(230, 300) and player.level == 1:
            if player.facing_right == True:
                player2.rect.x += 150
            if player.facing_right == False:
                player2.rect.x -= 150              

        if player.count in range(216, 250) and player.level == 2:
            if player.facing_right == True:
                player2.rect.x += 150
                player.rect.x -= 35
            if player.facing_right == False:
                player2.rect.x -= 150
                player.rect.x += 35

        if player.count2 in range(72, 100) and player.level == 2:
            if player.facing_right == True:
                player2.rect.x += 150
                player.rect.x -= 65
            if player.facing_right == False:
                player2.rect.x -= 150
                player.rect.x += 65

        if player.count in range(161, 250) and player.level == 3:
            if player.facing_right == True:
                player2.rect.x += 120
            if player.facing_right == False:
                player2.rect.x -= 120

        if player.count2 in range(186, 250) and player.level == 3:
            if player.facing_right == True:
                player2.rect.x += 110
            if player.facing_right == False:
                player2.rect.x -= 110

        #### PLAYER 2 ATTACKS ####

        if player2.count in range(148, 175) and player2.level == 1:
            if player2.facing_right == True:
                player.rect.x += 150
            if player2.facing_right == False:
                player.rect.x -= 150

        if player2.count2 in range(147, 175) and player2.level == 1:
            if player2.facing_right == True:
                player.rect.x += 150
            if player2.facing_right == False:
                player.rect.x -= 150

        if player2.count in range(247, 300) and player2.level == 2:
            if player2.facing_right == True:
                player.rect.x += 150
            if player2.facing_right == False:
                player.rect.x -= 150

        if player2.count2 in range(187, 250) and player2.level == 2:
            if player2.facing_right == True:
                player.rect.x += 150
            if player2.facing_right == False:
                player.rect.x -= 150

        if player2.count in range(198, 250) and player2.level == 3:
            if player2.facing_right == True:
                player.rect.x += 130
            if player2.facing_right == False:
                player.rect.x -= 130

        if player2.count2 in range(196, 250) and player2.level == 3:
            if player2.facing_right == True:
                player.rect.x += 130
            if player2.facing_right == False:
                player.rect.x -= 130

        if player2.combo1 == True and player2.level == 1 and player2.on_ground == False:
            player2.direction.y = -1
            player2.direction.x = 0
        else:
            pass
        if player2.combo2 == True and player2.level == 1 and player2.on_ground == False:
            player2.direction.y = -1
            player2.direction.x = 0
        else:
            pass

    def attack_positioning(self):
        player = self.player.sprite
        player2 = self.player2.sprite

        if player2.combo2 == True:
            if player2.on_ground == False:
                if player2.count2 in range(147, 175):
                    player.rect.bottom = player2.rect.bottom
                    player.on_ground = False
                    if player.rect.bottom == player2.rect.bottom:
                        player.apply_gravity()

    def attacks(self):
        player = self.player.sprite
        player2 = self.player2.sprite

        keys = pygame.key.get_pressed()

        if keys[pygame.K_z]:
            if player.combo1 == True:
                if keys[pygame.K_RSHIFT]:
                    player.on_screen = True
                    player2.hit1 = False
                    player2.combo1 = False
                
    def mid_attack(self):
        player = self.player.sprite
        player2 = self.player2.sprite

        keys = pygame.key.get_pressed()

        ## PLAYER 2 ##

        for event in pygame.event.get():
            if player.combo1 == True and player.level == 1:
                if event.type == KEYUP and event.key == K_z:
                    if player.count in range(1, 20):
                        player2.on_screen = True
                        player.rect.x = 300
                        player2.rect.x = 100
                    if player.count in range(21, 40):
                        player2.on_screen = True
                        player.rect.x += 100
                        player2.rect.x -= 100
                                   
    def hitcount_display(self):
        #### ALSO HEALTH/DAMAGE FOR COMBO MOVES ####

        player = self.player.sprite
        player2 = self.player2.sprite

        keys = pygame.key.get_pressed()

        font_hitcount = pygame.font.Font('/Users/charlieyorke/ace/imgs/pokemon-gb-font.tff/pokemonfont.ttf', 30)

        hitcount = font_hitcount.render('HIT', 1, (255, 255, 255))

        p1_hitcount = font_hitcount.render(f'HIT {player.hitcount}', 1, (255, 255, 255))

        p2_hitcount = font_hitcount.render(f'HIT {player2.hitcount}', 1, (255, 255, 255))

        #### PLAYER 1 HIT COUNT ####

        if player.combo1 == True and player.level == 1:
            screen.blit(hitcount, (132, 175))
            screen.blit(p1_hitcount, (132, 175))
            if player.count in range(2, 5):
                player.hitcount = 1
                player2.health(0.30)
            if player.count in range(10, 17):
                player.hitcount = 2
                player2.health(0.30)
            if player.count in range(23, 29):
                player.hitcount = 3
                player2.health(0.30)
            if player.count in range(36, 42):
                player.hitcount = 4
                player2.health(0.30)
            if player.count in range(50, 56):
                player.hitcount = 5
                player2.health(0.30)
            if player.count in range(63, 70):
                player.hitcount = 6
                player2.health(0.30)
            if player.count in range(82, 88):
                player.hitcount = 7
                player2.health(0.30)
            if player.count in range(100, 107):
                player.hitcount = 8
                player2.health(0.30)
            if player.count in range(118, 125):
                player.hitcount = 9
                player2.health(0.30)
            if player.count in range(135, 142):
                player.hitcount = 10
                player2.health(0.30)
            if player.count > 143:
                player.hitcount = 10
                screen.blit(p1_hitcount, (132, 175))

        if player.combo2 == True and player.level == 1:
            screen.blit(hitcount, (132, 175))
            screen.blit(p1_hitcount, (132, 175))
            if player.count2 in range(1, 3):
                player.hitcount = 1
                player2.health(0.35)
            if player.count2 in range(4, 6):
                player.hitcount = 2
                player2.health(0.35)
            if player.count2 in range(7, 10):
                player.hitcount = 3
                player2.health(0.35)
            if player.count2 in range(11, 13):
                player.hitcount = 4
                player2.health(0.35)
            if player.count2 in range(16, 20):
                player.hitcount = 5
                player2.health(0.35)
            if player.count2 in range(21, 23):
                player.hitcount = 6
                player2.health(0.35)
            if player.count2 in range(24, 26):
                player.hitcount = 7
                player2.health(0.35)
            if player.count2 in range(27, 30):
                player.hitcount = 8
                player2.health(0.35)
            if player.count2 in range(31, 33):
                player.hitcount = 9
                player2.health(0.35)
            if player.count2 in range(34, 36):
                player.hitcount = 10
                player2.health(0.35)
            if player.count2 in range(37, 40):
                player.hitcount = 11
                player2.health(0.35)
            if player.count2 > 41:
                player.hitcount = 11
                screen.blit(p1_hitcount, (132, 175))

        if player.combo1 == True and player.level == 2:
            screen.blit(hitcount, (132, 175))
            screen.blit(p1_hitcount, (132, 175))
            if player.count in range(4, 8):
                player.hitcount = 1
                player2.health(0.45)
            if player.count in range(16, 21):
                player.hitcount = 2
                player2.health(0.45)
            if player.count in range(29, 35):
                player.hitcount = 3
                player2.health(0.45)
            if player.count in range(49, 55):
                player.hitcount = 4
                player2.health(0.45)
            if player.count in range(69, 75):
                player.hitcount = 5
                player2.health(0.45)
            if player.count in range(88, 94):
                player.hitcount = 6
                player2.health(0.45)
            if player.count in range(107, 114):
                player.hitcount = 7
                player2.health(0.45)
            if player.count in range(123, 127):
                player.hitcount = 8
                player2.health(0.45)
            if player.count in range(141, 146):
                player.hitcount = 9
                player2.health(0.45)
            if player.count in range(151, 155):
                player.hitcount = 10
                player2.health(0.45)
            if player.count in range(173, 179):
                player.hitcount = 11
                player2.health(0.45)
            if player.count in range(183, 189):
                player.hitcount = 12
                player2.health(0.45)
            if player.count > 190:
                player.hitcount = 12
                screen.blit(p1_hitcount, (132, 175))

        if player.combo2 == True and player.level == 2:
            screen.blit(hitcount, (132, 175))
            screen.blit(p1_hitcount, (132, 175))
            if player.count2 in range(1, 2):
                player.hitcount = 1
                player2.health(0.45)
            if player.count2 in range(3, 5):
                player.hitcount = 2
                player2.health(0.45)
            if player.count2 in range(7, 9):
                player.hitcount = 3
                player2.health(0.45)
            if player.count2 in range(11, 13):
                player.hitcount = 4
                player2.health(0.45)
            if player.count2 in range(17, 20):
                player.hitcount = 5
                player2.health(0.45)
            if player.count2 in range(23, 26):
                player.hitcount = 6
                player2.health(0.45)
            if player.count2 in range(28, 31):
                player.hitcount = 7
                player2.health(0.45)
            if player.count2 in range(33, 36):
                player.hitcount = 8
                player2.health(0.45)
            if player.count2 in range(39, 42):
                player.hitcount = 9
                player2.health(0.45)
            if player.count2 in range(44, 46):
                player.hitcount = 10
                player2.health(0.45)
            if player.count2 in range(49, 51):
                player.hitcount = 11
                player2.health(0.45)
            if player.count2 in range(55, 58):
                player.hitcount = 12
                player2.health(0.45)
            if player.count2 in range(61, 63):
                player.hitcount = 13
                player2.health(0.45)
            if player.count2 in range(65, 68):
                player.hitcount = 14
                player2.health(0.45)
            if player.count2 > 69:
                player.hitcount = 14
                screen.blit(p1_hitcount, (132, 175))

        if player.combo1 == True and player.level == 3:
            screen.blit(hitcount, (132, 175))
            screen.blit(p1_hitcount, (132, 175))
            if player.count in range(3, 6):
                player.hitcount = 1
                player2.health(0.60)
            if player.count in range(9, 14):
                player.hitcount = 2
                player2.health(0.60)
            if player.count in range(21, 25):
                player.hitcount = 3
                player2.health(0.60)
            if player.count in range(39, 44):
                player.hitcount = 4
                player2.health(0.60)
            if player.count in range(49, 53):
                player.hitcount = 5
                player2.health(0.60)
            if player.count in range(60, 65):
                player.hitcount = 6
                player2.health(0.60)
            if player.count in range(79, 83):
                player.hitcount = 7
                player2.health(0.60)
            if player.count in range(88, 92):
                player.hitcount = 8
                player2.health(0.60)
            if player.count in range(101, 105):
                player.hitcount = 9
                player2.health(0.60)
            if player.count in range(113, 117):
                player.hitcount = 10
                player2.health(0.60)
            if player.count in range(125, 129):
                player.hitcount = 11
                player2.health(0.60)
            if player.count in range(136, 141):
                player.hitcount = 12
                player2.health(0.60)
            if player.count > 142:
                player.hitcount = 12
                screen.blit(p1_hitcount, (132, 175))

        if player.combo2 == True and player.level == 3:
            screen.blit(hitcount, (132, 175))
            screen.blit(p1_hitcount, (132, 175))
            if player.count2 in range(2, 5):
                player.hitcount = 1
                player2.health(0.60)
            if player.count2 in range(7, 11):
                player.hitcount = 2
                player2.health(0.60)
            if player.count2 in range(24, 28):
                player.hitcount = 3
                player2.health(0.60)
            if player.count2 in range(35, 39):
                player.hitcount = 4
                player2.health(0.60)
            if player.count2 in range(49, 53):
                player.hitcount = 5
                player2.health(0.60)
            if player.count2 in range(63, 67):
                player.hitcount = 6
                player2.health(0.60)
            if player.count2 in range(78, 83):
                player.hitcount = 7
                player2.health(0.60)
            if player.count2 in range(90, 93):
                player.hitcount = 8
                player2.health(0.60)
            if player.count2 in range(99, 104):
                player.hitcount = 9
                player2.health(0.60)
            if player.count2 in range(112, 116):
                player.hitcount = 10
                player2.health(0.60)
            if player.count2 in range(123, 127):
                player.hitcount = 11
                player2.health(0.60)
            if player.count2 in range(137, 142):
                player.hitcount = 12
                player2.health(0.60)
            if player.count2 in range(152, 155):
                player.hitcount = 13
                player2.health(0.60)
            if player.count2 in range(159, 164):
                player.hitcount = 14
                player2.health(0.60)
            if player.count2 > 165:
                player.hitcount = 14
                screen.blit(p1_hitcount, (132, 175))

        #### PLAYER 2 HIT COUNT ####

        if player2.combo1 == True and player2.level == 1:
            screen.blit(hitcount, (915, 175))
            screen.blit(p2_hitcount, (915, 175))
            if player2.count in range(3, 8):
                player2.hitcount = 1
                player.health(0.30)
            if player2.count in range(15, 22):
                player2.hitcount = 2
                player.health(0.30)
            if player2.count in range(29, 36):
                player2.hitcount = 3
                player.health(0.30)
            if player2.count in range(48, 56):
                player2.hitcount = 4
                player.health(0.30)
            if player2.count in range(59, 68):
                player2.hitcount = 5
                player.health(0.30)
            if player2.count in range(78, 86):
                player2.hitcount = 6
                player.health(0.30)
            if player2.count in range(88, 96):
                player2.hitcount = 7
                player.health(0.30)
            if player2.count in range(101, 107):
                player2.hitcount = 8
                player.health(0.30)
            if player2.count in range(118, 125):
                player2.hitcount = 9
                player.health(0.30)
            if player2.count > 126:
                player2.hitcount = 9
                screen.blit(hitcount, (915, 175))

        if player2.combo2 == True and player2.level == 1:
            screen.blit(hitcount, (915, 175))
            screen.blit(p2_hitcount, (915, 175))
            if player2.count2 in range(2, 7):
                player2.hitcount = 1
                player.health(0.35)
            if player2.count2 in range(13, 19):
                player2.hitcount = 2
                player.health(0.35)
            if player2.count2 in range(27, 34):
                player2.hitcount = 3
                player.health(0.35)
            if player2.count2 in range(42, 47):
                player2.hitcount = 4
                player.health(0.35)
            if player2.count2 in range(57, 62):
                player2.hitcount = 5
                player.health(0.35)
            if player2.count2 in range(66, 73):
                player2.hitcount = 6
                player.health(0.35)
            if player2.count2 in range(82, 88):
                player2.hitcount = 7
                player.health(0.35)
            if player2.count2 in range(99, 106):
                player2.hitcount = 8
                player.health(0.35)
            if player2.count2 in range(112, 118):
                player2.hitcount = 9
                player.health(0.35)
            if player2.count2 in range(128, 135):
                player2.hitcount = 10
                player.health(0.35)
            if player2.count2 in range(139, 143):
                player2.hitcount = 11
                player.health(0.35)
            if player2.count2 > 144:
                screen.blit(hitcount, (915, 175))
                player2.hitcount = 11

        if player2.combo1 == True and player2.level == 2:
            screen.blit(hitcount, (915, 175))
            screen.blit(p2_hitcount, (915, 175))
            if player2.count in range(3, 7):
                player2.hitcount = 1
                player.health(0.45)
            if player2.count in range(17, 23):
                player2.hitcount = 2
                player.health(0.45)
            if player2.count in range(42, 47):
                player2.hitcount = 3
                player.health(0.45)
            if player2.count in range(57, 64):
                player2.hitcount = 4
                player.health(0.45)
            if player.count in range(76, 83):
                player2.hitcount = 5
                player.health(0.45)
            if player2.count in range(98, 104):
                player2.hitcount = 6
                player.health(0.45)
            if player2.count in range(112, 118):
                player2.hitcount = 7
                player.health(0.45)
            if player2.count in range(138, 144):
                player2.hitcount = 8
                player.health(0.45)
            if player2.count in range(159, 165):
                player2.hitcount = 9
                player.health(0.45)
            if player2.count in range(179, 186):
                player2.hitcount = 10
                player.health(0.45)
            if player2.count in range(199, 205):
                player2.hitcount = 11
                player.health(0.45)
            if player2.count in range(209, 216):
                player2.hitcount = 12
                player.health(0.45)
            if player2.count in range(229, 236):
                player2.hitcount = 13
                player.health(0.45)
            if player2.count > 237:
                screen.blit(hitcount, (915, 175))
                player2.hitcount = 13

        if player2.combo2 == True and player2.level == 2:
            screen.blit(hitcount, (915, 175))
            screen.blit(p2_hitcount, (915, 175))
            if player2.count2 in range(3, 7):
                player2.hitcount = 1
                player.health(0.45)
            if player2.count2 in range(11, 14):
                player2.hitcount = 2
                player.health(0.45)
            if player2.count2 in range(25, 29):
                player2.hitcount = 3
                player.health(0.45)
            if player2.count2 in range(38, 43):
                player2.hitcount = 4
                player.health(0.45)
            if player2.count2 in range(53, 58):
                player2.hitcount = 5
                player.health(0.45)
            if player2.count2 in range(68, 73):
                player2.hitcount = 6
                player.health(0.45)
            if player2.count2 in range(82, 86):
                player2.hitcount = 7
                player.health(0.45)
            if player2.count2 in range(95, 99):
                player2.hitcount = 8
                player.health(0.45)
            if player2.count2 in range(106, 109):
                player2.hitcount = 9
                player.health(0.45)
            if player2.count2 in range(120, 124):
                player2.hitcount = 10
                player.health(0.45)
            if player2.count2 in range(134, 138):
                player2.hitcount = 11
                player.health(0.45)
            if player2.count2 in range(148, 152):
                player2.hitcount = 12
                player.health(0.45)
            if player2.count2 in range(164, 168):
                player2.hitcount = 13
                player.health(0.45)
            if player2.count2 > 169:
                screen.blit(hitcount, (915, 175))
                player2.hitcount = 13

        if player2.combo1 == True and player2.level == 3:
            screen.blit(hitcount, (915, 175))
            screen.blit(p2_hitcount, (915, 175))
            if player2.count in range(2, 6):
                player2.hitcount = 1
                player.health(0.60)
            if player2.count in range(12, 17):
                player2.hitcount = 2
                player.health(0.60)
            if player2.count in range(26, 30):
                player2.hitcount = 3
                player.health(0.60)
            if player2.count in range(41, 45):
                player2.hitcount = 4
                player.health(0.60)
            if player2.count in range(56, 60):
                player2.hitcount = 5
                player.health(0.60)
            if player2.count in range(71, 75):
                player2.hitcount = 6
                player.health(0.60)
            if player2.count in range(83, 87):
                player2.hitcount = 7
                player.health(0.60)
            if player2.count in range(99, 103):
                player2.hitcount = 8
                player.health(0.60)
            if player2.count in range(111, 116):
                player2.hitcount = 9
                player.health(0.60)
            if player2.count in range(121, 125):
                player2.hitcount = 10
                player.health(0.60)
            if player2.count in range(134, 139):
                player2.hitcount = 11
                player.health(0.60)
            if player2.count in range(151, 154):
                player2.hitcount = 12
                player.health(0.60)
            if player2.count in range(160, 164):
                player2.hitcount = 13
                player.health(0.60)
            if player2.count in range(177, 181):
                player2.hitcount = 14
                player.health(0.60)
            if player2.count > 182:
                screen.blit(hitcount, (915, 175))
                player2.hitcount = 14

        if player2.combo2 == True and player2.level == 3:
            screen.blit(hitcount, (915, 175))
            screen.blit(p2_hitcount, (915, 175))
            if player2.count2 in range(2, 5):
                player2.hitcount = 1
                player.health(0.60)
            if player2.count2 in range(13, 16):
                player2.hitcount = 2
                player.health(0.60)
            if player2.count2 in range(24, 29):
                player2.hitcount = 3
                player.health(0.60)
            if player2.count2 in range(36, 41):
                player2.hitcount = 4
                player.health(0.60)
            if player2.count2 in range(49, 53):
                player2.hitcount = 5
                player.health(0.60)
            if player2.count2 in range(60, 64):
                player2.hitcount = 6
                player.health(0.60)
            if player2.count2 in range(75, 79):
                player2.hitcount = 7
                player.health(0.60)
            if player2.count2 in range(90, 93):
                player2.hitcount = 8
                player.health(0.60)
            if player2.count2 in range(104, 109):
                player2.hitcount = 9
                player.health(0.60)
            if player2.count2 in range(120, 124):
                player2.hitcount = 10
                player.health(0.60)
            if player2.count2 in range(132, 136):
                player2.hitcount = 11
                player.health(0.60)
            if player2.count2 in range(147, 151):
                player2.hitcount = 12
                player.health(0.60)
            if player2.count2 in range(159, 164):
                player2.hitcount = 13
                player.health(0.60)
            if player2.count2 in range(175, 179):
                player2.hitcount = 14
                player.health(0.60)
            if player2.count2 > 180:
                player2.hitcount = 14
                screen.blit(hitcount, (915, 175))

    def display(self):
        player = self.player.sprite
        player2 = self.player2.sprite

        if player.on_screen == True:
            self.player.draw(self.display_surface)

        if player2.on_screen == True:
            self.player2.draw(self.display_surface)
            
    def sound_effects(self):
        player = self.player.sprite
        player2 = self.player2.sprite

        #### PLAYER 1 SOUND EFFECTS ####

        if player.combo1 == True and player.level == 1:
            if player.count in range(2, 5):
                pygame.mixer.music.load('/Users/charlieyorke/ace/imgs/punch.mp3')
                pygame.mixer.music.play()
            if player.count in range(10, 17):
                pygame.mixer.music.play()
            if player.count in range(23, 29):
                pygame.mixer.music.load('/Users/charlieyorke/ace/imgs/kick.mp3')
                pygame.mixer.music.play()
            if player.count in range(36, 42):
                pygame.mixer.music.play()
            if player.count in range(50, 56):
                pygame.mixer.music.load('/Users/charlieyorke/ace/imgs/punch.mp3')
                pygame.mixer.music.play()
            if player.count in range(63, 70):
                pygame.mixer.music.play()
            if player.count in range(82, 88):
                pygame.mixer.music.play()
            if player.count in range(100, 107):
                pygame.mixer.music.play()
            if player.count in range(118, 125):
                pygame.mixer.music.load('/Users/charlieyorke/ace/imgs/kick.mp3')
                pygame.mixer.music.play()
            if player.count in range(135, 142):
                pygame.mixer.music.play()

        if player.combo2 == True and player.level == 1:
            if player.count2 in range(1, 4):
                pygame.mixer.music.load('/Users/charlieyorke/ace/imgs/punch.mp3')
                pygame.mixer.music.play()
            if player.count2 in range(5, 7):
                pygame.mixer.music.load('/Users/charlieyorke/ace/imgs/kick.mp3')
                pygame.mixer.music.play()
            if player.count2 in range(9, 13):
                pygame.mixer.music.load('/Users/charlieyorke/ace/imgs/punch.mp3')
                pygame.mixer.music.play()
            if player.count2 in range(15, 19):
                pygame.mixer.music.load('/Users/charlieyorke/ace/imgs/kick.mp3')
                pygame.mixer.music.play()
            if player.count2 in range(20, 24):
                pygame.mixer.music.load('/Users/charlieyorke/ace/imgs/punch.mp3')
                pygame.mixer.music.play()
            if player.count2 in range(26, 30):
                pygame.mixer.music.play()
            if player.count2 in range(32, 36):
                pygame.mixer.music.play()
            if player.count2 in range(37, 40):
                pygame.mixer.music.play()
            if player.count2 in range(42, 46):
                pygame.mixer.music.play()
            if player.count2 in range(47, 51):
                pygame.mixer.music.load('/Users/charlieyorke/ace/imgs/kick.mp3')
                pygame.mixer.music.play()
            if player.count2 in range(53, 57):
                pygame.mixer.music.play()

        if player.combo1 == True and player.level == 2:
            if player.count in range(1, 5):
                pygame.mixer.music.load('/Users/charlieyorke/ace/imgs/punch.mp3')
                pygame.mixer.music.play()
            if player.count in range(13, 17):
                pygame.mixer.music.play()
            if player.count in range(25, 29):
                pygame.mixer.music.play()
            if player.count in range(51, 55):
                pygame.mixer.music.play()
            if player.count in range(65, 69):
                pygame.mixer.music.play()
            if player.count in range(88, 92):
                pygame.mixer.music.play()
            if player.count in range(100, 107):
                pygame.mixer.music.load('/Users/charlieyorke/ace/imgs/kick.mp3')
                pygame.mixer.music.play()
            if player.count in range(120, 127):
                pygame.mixer.music.play()
            if player.count in range(137, 144):
                pygame.mixer.music.play()
            if player.count in range(153, 157):
                pygame.mixer.music.load('/Users/charlieyorke/ace/imgs/punch.mp3')
                pygame.mixer.music.play()
            if player.count in range(170, 174):
                pygame.mixer.music.play()
            if player.count in range(180, 184):
                pygame.mixer.music.play()

        #### PLAYER 2 SOUND EFFECTS ####

        if player2.combo1 == True and player2.level == 1:
            if player2.count in range(4, 6):
                pygame.mixer.music.load('/Users/charlieyorke/ace/imgs/sword.mp3')
                pygame.mixer.music.play()
            if player2.count in range(17, 19):
                pygame.mixer.music.play()
            if player2.count in range(31, 33):
                pygame.mixer.music.play()
            if player2.count in range(50, 52):
                pygame.mixer.music.play()
            if player2.count in range(63, 65):
                pygame.mixer.music.play()
            if player2.count in range(81, 83):                
                pygame.mixer.music.play()
            if player2.count in range(91, 93):               
                pygame.mixer.music.play()
            if player2.count in range(103, 105):               
                pygame.mixer.music.play()
            if player2.count in range(121, 123):               
                pygame.mixer.music.play()

        if player2.combo2 == True and player2.level == 1:
            if player2.count2 in range(1, 3):
                pygame.mixer.music.load('/Users/charlieyorke/ace/imgs/sword.mp3')
                pygame.mixer.music.play()
            if player2.count2 in range(9, 11):
                pygame.mixer.music.play()
            if player2.count2 in range(23, 25):
                pygame.mixer.music.play()
            if player2.count2 in range(35, 37):
                pygame.mixer.music.play()
            if player2.count2 in range(47, 49):
                pygame.mixer.music.play()
            if player2.count2 in range(61, 63):
                pygame.mixer.music.play()
            if player2.count2 in range(73, 75):
                pygame.mixer.music.play()
            if player2.count2 in range(89, 91):
                pygame.mixer.music.play()
            if player2.count2 in range(101, 103):
                pygame.mixer.music.play()
            if player2.count2 in range(113, 115):
                pygame.mixer.music.play()
            if player2.count2 in range(125, 127):
                pygame.mixer.music.play()

        if player2.combo1 == True and player2.level == 2:
            if player2.count in range(1, 3):
                pygame.mixer.music.load('/Users/charlieyorke/ace/imgs/sword.mp3')
                pygame.mixer.music.play()
            if player2.count in range(13, 15):
                pygame.mixer.music.play()
            if player2.count in range(35, 37):
                pygame.mixer.music.play()
            if player2.count in range(49, 51):
                pygame.mixer.music.play()
            if player2.count in range(70, 72):
                pygame.mixer.music.play()
            if player2.count in range(90, 92):
                pygame.mixer.music.play()
            if player2.count in range(109, 111):
                pygame.mixer.music.play()
            if player2.count in range(130, 132):
                pygame.mixer.music.play()
            if player2.count in range(150, 152):
                pygame.mixer.music.play()
            if player2.count in range(170, 172):
                pygame.mixer.music.play()
            if player2.count in range(190, 192):
                pygame.mixer.music.play()
            if player2.count in range(205, 207):
                pygame.mixer.music.play()
            if player2.count in range(223, 225):
                pygame.mixer.music.play()

        if player2.combo2 == True and player2.level == 2:
            if player2.count2 in range(2, 4):
                pygame.mixer.music.load('/Users/charlieyorke/ace/imgs/sword.mp3')
                pygame.mixer.music.play()
            if player2.count2 in range(9, 11):
                pygame.mixer.music.play()
            if player2.count2 in range(23, 25):
                pygame.mixer.music.play()
            if player2.count2 in range(35, 37):
                pygame.mixer.music.play()
            if player2.count2 in range(49, 51):
                pygame.mixer.music.play()
            if player2.count2 in range(61, 63):
                pygame.mixer.music.play()
            if player2.count2 in range(73, 75):
                pygame.mixer.music.play()
            if player2.count2 in range(85, 87):
                pygame.mixer.music.play()
            if player2.count2 in range(97, 99):
                pygame.mixer.music.play()
            if player2.count2 in range(111, 113):
                pygame.mixer.music.play()
            if player2.count2 in range(125, 127):
                pygame.mixer.music.play()
            if player2.count2 in range(135, 137):
                pygame.mixer.music.play()
            if player2.count2 in range(151, 153):
                pygame.mixer.music.play()

        if player2.combo1 == True and player2.level == 3:
            if player2.count in range(1, 3):
                pygame.mixer.music.load('/Users/charlieyorke/ace/imgs/sword.mp3')
                pygame.mixer.music.play()
            if player2.count in range(13, 15):
                pygame.mixer.music.play()
            if player2.count in range(25, 27):
                pygame.mixer.music.play()
            if player2.count in range(37, 39):
                pygame.mixer.music.play()
            if player2.count in range(49, 51):
                pygame.mixer.music.play()
            if player2.count in range(61, 63):
                pygame.mixer.music.play()
            if player2.count in range(73, 75):
                pygame.mixer.music.play()
            if player2.count in range(85, 87):
                pygame.mixer.music.play()
            if player2.count in range(99, 101):
                pygame.mixer.music.play()
            if player2.count in range(111, 113):
                pygame.mixer.music.play()
            if player2.count in range(123, 125):
                pygame.mixer.music.play()
            if player2.count in range(135, 137):
                pygame.mixer.music.play()
            if player2.count in range(147, 149):
                pygame.mixer.music.play()
            if player2.count in range(163, 165):
                pygame.mixer.music.play()

        if player2.combo2 == True and player2.level == 3:
            if player2.count2 in range(1, 3):
                pygame.mixer.music.load('/Users/charlieyorke/ace/imgs/sword.mp3')
                pygame.mixer.music.play()
            if player2.count2 in range(11, 13):
                pygame.mixer.music.play()
            if player2.count2 in range(23, 25):
                pygame.mixer.music.play()
            if player2.count2 in range(35, 37):
                pygame.mixer.music.play()
            if player2.count2 in range(47, 49):
                pygame.mixer.music.play()
            if player2.count2 in range(59, 61):
                pygame.mixer.music.play()
            if player2.count2 in range(71, 73):
                pygame.mixer.music.play()
            if player2.count2 in range(83, 85):
                pygame.mixer.music.play()
            if player2.count2 in range(97, 99):
                pygame.mixer.music.play()
            if player2.count2 in range(113, 115):
                pygame.mixer.music.play()
            if player2.count2 in range(127, 129):
                pygame.mixer.music.play()
            if player2.count2 in range(139, 141):
                pygame.mixer.music.play()
            if player2.count2 in range(153, 155):
                pygame.mixer.music.play()
            if player2.count2 in range(169, 171):
                pygame.mixer.music.play()

    def image_imports(self):
        player = self.player.sprite
        player2 = self.player2.sprite

        # player 1 health bar 
        pygame.draw.rect(screen, (255, 0, 0), (206, 45, 320, 32))
        pygame.draw.rect(screen, (255, 255, 0), (206, 45, player.max_health, 32))

        # player 2 health bar 
        pygame.draw.rect(screen, (255, 255, 0), (664, 45, 320, 32))
        pygame.draw.rect(screen, (255, 0, 0), (664, 45, player2.max_health, 32))

        # player 1 level bar 
        pygame.draw.rect(screen, (255, 128, 0), (197, 90, 234, 20))
        pygame.draw.rect(screen, (0, 0, 255), (197, 90, player.charge, 20))

        # player 2 level bar
        pygame.draw.rect(screen, (0, 0, 255), (759, 90, 234, 20))
        pygame.draw.rect(screen, (255, 128, 0), (759, 90, player2.charge, 20))

        bar_covers = pygame.transform.scale(pygame.image.load('/Users/charlieyorke/ace/imgs/healthbarcover.png'), (450, 100)).convert_alpha()

        flipped_bar_covers = pygame.transform.flip(bar_covers, True, False)

        screen.blit(bar_covers, (120, 30))

        screen.blit(flipped_bar_covers, (620, 30))

        font = pygame.font.Font('/Users/charlieyorke/ace/imgs/pokemon-gb-font.tff/pokemonfont.ttf', 15)

        p1_level_font = font.render(f'Level:{player.level}', 1, (255, 255, 255))

        screen.blit(p1_level_font, (130, 125))

        p2_level_font = font.render(f'Level:{player2.level}', 1, (255, 255, 255))

        screen.blit(p2_level_font, (960, 125))

        n_pfp = pygame.image.load('/Users/charlieyorke/ace/imgs/n_hedshot.png')

        s_pfp = pygame.image.load('/Users/charlieyorke/ace/imgs/s_hedshot.png')

        screen.blit(n_pfp, (-15, -81))

        screen.blit(s_pfp, (1010, -80))

    def map_select(self):
        pass

    def loss(self):
        player = self.player.sprite
        player2 = self.player2.sprite

        if player.max_health < 1:
            self.p2_winner = True
        if player2.max_health > 320:
            self.p1_winner = True

        if self.p1_winner == True or self.p2_winner == True:
            self.running = False

        if self.running == True:
            self.p1_winner = False
            self.p2_winner = False

    def run(self):

        if self.running == True:

            self.player.update()
            self.player2.update()
            self.horizontal_movement_collision()
            self.vertical_movement_collision()

            self.test()

            self.positioning()

            self.collisions()

            self.adding_attacks()

            self.test_collisions()

            self.hitcount_display()

            self.display()

            self.attack_positioning()

            self.mid_attack()

            #self.attacks()

        self.image_imports()

        self.loss()

    def reset(self):
        player = self.player.sprite
        player2 = self.player2.sprite

        self.running = True
        self.p1_winner = False
        self.p2_winner = False

        player.rect.x = 50 
        player.rect.y = 640
        player.max_health = 320
        player.level = 1
        player.charge = 0

        player2.rect.x = 1050
        player2.rect.y = 640
        player2.max_health = 1
        player2.level = 1
        player2.charge = 234

        main()

level = Level(screen)

class StartButton:
    def __init__(self, x, y, fontimage):
        self.fontimage = fontimage

        self.start_rect = self.fontimage.get_rect()
        self.start_rect.center = (x, y)

        self.clicked = False
    
    def draw(self):

        action = False

        pos = pygame.mouse.get_pos()

        screen.blit(self.fontimage, (self.start_rect.x, self.start_rect.y))

        if self.start_rect.collidepoint(pos):
            pygame.draw.rect(screen, (255, 0, 0), (500, 125, 200, 50), 3)
            #self.clicked = True
            
            if pygame.mouse.get_pressed()[0] == 1 or pygame.mouse.get_pressed()[0] == 3 and self.clicked == False:
                self.clicked = True
                action = True
            else:
                self.clicked = False

        return action
class ExitButton:
    def __init__(self, x, y, image):
        self.image = image

        self.exit_rect = self.image.get_rect()
        self.exit_rect.center = (x, y)

        self.clicked = False

    def draw(self):

        action = False
        
        pos = pygame.mouse.get_pos()

        screen.blit(self.image, (self.exit_rect.x, self.exit_rect.y))

        if self.exit_rect.collidepoint(pos) and self.clicked == False:
            pygame.draw.rect(screen, (255, 0, 0), (500, 425, 200, 50), 3)
            self.clicked = True

            if pygame.mouse.get_pressed()[0] == 1 or pygame.mouse.get_pressed()[0] == 3:
                self.clicked = True
                action = True
            else:
                self.clicked = False

        return action
class SettingsButton:
    def __init__(self, x, y, image):
        self.image = image

        self.settings_rect = self.image.get_rect()
        self.settings_rect.center = (x, y)

        self.clicked = False

    def draw(self):

        action = False

        pos = pygame.mouse.get_pos()

        screen.blit(self.image, (self.settings_rect.x, self.settings_rect.y))

        if self.settings_rect.collidepoint(pos):
            pygame.draw.rect(screen, (255, 0, 0), (490, 275, 225, 50), 3)
            #self.clicked = True

            if pygame.mouse.get_pressed()[0] == 1 or pygame.mouse.get_pressed()[0] == 3 and self.clicked == False:
                self.clicked = True
                action = True
            else:
                self.clicked = False

        return action
class BackButton:
    def __init__(self, x, y, image):
        self.image = image

        self.back_rect = self.image.get_rect()
        self.back_rect.center = (x, y)

        self.clicked = False

    def draw(self):

        action = False

        pos = pygame.mouse.get_pos()

        screen.blit(self.image, (self.back_rect.x, self.back_rect.y))

        if self.back_rect.collidepoint(pos):
            pygame.draw.rect(screen, (255, 0, 0), (5, 30, 90, 35), 3)
            #self.clicked = True

            if pygame.mouse.get_pressed()[0] == 1 or pygame.mouse.get_pressed()[0] == 3 and self.clicked == False:
                self.clicked = True
                action = True
            else:
                self.clicked = False

        return action
class InGamePauseButton:
    def __init__(self, x, y, image):
        self.image = image

        self.pause_rect = self.image.get_rect()
        self.pause_rect.center = (x, y)

        self.clicked = False

    def draw(self):

        action = False

        pos = pygame.mouse.get_pos()

        screen.blit(self.image, (self.pause_rect.x, self.pause_rect.y))

        if self.pause_rect.collidepoint(pos):
            #pygame.draw.rect(screen, (255, 0, 0), (1100, 30, 50, 40), 3)
            #self.clicked = True

            if pygame.mouse.get_pressed()[0] == 1 or pygame.mouse.get_pressed()[0] == 3 and self.clicked == False:
                self.clicked = True
                action = True
            else:
                self.clicked = False

        return action
class MenuButton:
    def __init__(self, x, y, image):
        self.image = image

        self.menu_rect = self.image.get_rect()
        self.menu_rect.center = (x, y)

        self.clicked = False

    def draw(self):

        action = False

        pos = pygame.mouse.get_pos()

        screen.blit(self.image, (self.menu_rect.x, self.menu_rect.y))

        if self.menu_rect.collidepoint(pos):
            #pygame.draw.rect(screen, (255, 0, 0), (5, 30, 90, 35), 3)
            #self.clicked = True

            if pygame.mouse.get_pressed()[0] == 1 or pygame.mouse.get_pressed()[0] == 3 and self.clicked == False:
                self.clicked = True
                action = True
            else:
                self.clicked = False

        return action
class ReturnButton:
    def __init__(self, x, y, image):
        self.image = image

        self.return_rect = self.image.get_rect()
        self.return_rect.center = (x, y)

        self.clicked = False

    def draw(self):

        action = False

        pos = pygame.mouse.get_pos()

        screen.blit(self.image, (self.return_rect.x, self.return_rect.y))

        if self.return_rect.collidepoint(pos):
            #pygame.draw.rect(screen, (255, 0, 0), (5, 30, 90, 35), 3)
            #self.clicked = True

            if pygame.mouse.get_pressed()[0] == 1 or pygame.mouse.get_pressed()[0] == 3 and self.clicked == False:
                self.clicked = True
                action = True
            else:
                self.clicked = False

        return action
class PlayAgain:
    def __init__(self, x, y, image):
        self.image = image

        self.return_rect = self.image.get_rect()
        self.return_rect.center = (x, y)

        self.clicked = False

    def draw(self):

        action = False

        pos = pygame.mouse.get_pos()

        screen.blit(self.image, (self.return_rect.x, self.return_rect.y))

        if self.return_rect.collidepoint(pos):
            pygame.draw.rect(screen, (255, 0, 0), (300, 325, 200, 50), 3)
            self.clicked = True

            if pygame.mouse.get_pressed()[0] == 1 or pygame.mouse.get_pressed()[0] == 3 and self.clicked == False:
                self.clicked = True
                action = True
            else:
                self.clicked = False

        return action
class AfterGameMenu:
    def __init__(self, x, y, image):
        self.image = image

        self.return_rect = self.image.get_rect()
        self.return_rect.center = (x, y)

        self.clicked = False

    def draw(self):

        action = False

        pos = pygame.mouse.get_pos()

        screen.blit(self.image, (self.return_rect.x, self.return_rect.y))

        if self.return_rect.collidepoint(pos):
            pygame.draw.rect(screen, (255, 0, 0), (650, 325, 200, 50), 3)
            self.clicked = True

            if pygame.mouse.get_pressed()[0] == 1 or pygame.mouse.get_pressed()[0] == 3 and self.clicked == False:
                self.clicked = True
                action = True
            else:
                self.clicked = False

        return action
class Map1:
    def __init__(self, x, y, image):
        self.image = image

        self.return_rect = self.image.get_rect()
        self.return_rect.center = (x, y)

        self.clicked = False

    def draw(self):

        action = False

        pos = pygame.mouse.get_pos()

        screen.blit(self.image, (self.return_rect.x, self.return_rect.y))

        if self.return_rect.collidepoint(pos):
            pygame.draw.rect(screen, (255, 0, 0), (89, 144, 157, 90), 5)
            self.clicked = True

            if pygame.mouse.get_pressed()[0] == 1 or pygame.mouse.get_pressed()[0] == 3 and self.clicked == False:
                self.clicked = True
                action = True
            else:
                self.clicked = False

        return action
class Map2:
    def __init__(self, x, y, image):
        self.image = image

        self.return_rect = self.image.get_rect()
        self.return_rect.center = (x, y)

        self.clicked = False

    def draw(self):

        action = False

        pos = pygame.mouse.get_pos()

        screen.blit(self.image, (self.return_rect.x, self.return_rect.y))

        if self.return_rect.collidepoint(pos):
            pygame.draw.rect(screen, (255, 0, 0), (89, 277, 157, 90), 5)
            self.clicked = True

            if pygame.mouse.get_pressed()[0] == 1 or pygame.mouse.get_pressed()[0] == 3 and self.clicked == False:
                self.clicked = True
                action = True
            else:
                self.clicked = False

        return action

start_button = StartButton(600, 150, start_image)
exit_button = ExitButton(600, 450, exit_image)
settings_button = SettingsButton(600, 300, settings_image)
back_button = BackButton(50, 50, back_image)
pause_button = InGamePauseButton(593, 30, pause_image)
menu_button = MenuButton(600, 250, menu_image)
return_button = ReturnButton(600, 400, return_image)
playagain_button = PlayAgain(400, 350, startagain)
aftergamemenu_button = AfterGameMenu(750, 350, menu)
map1_select = Map1(165, 187, mp1)
map2_select = Map2(165, 320, mp2)

def main():
    game_count = 0
    win_count = 0
    fight_count = 0
    FPS = 100
    run = True
    while run:
        print(game_count)
        pygame.init()

        clock.tick(FPS)
        pygame.display.update()

        fight_count += 1      

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                sys.exit

            if event.type == MOUSEBUTTONDOWN and playagain_button.draw():
                level.reset()
            if event.type == MOUSEBUTTONDOWN and aftergamemenu_button.draw():
                main_menu()

        if level.map1 == True:
            game_count += 1
            if game_count in range(1, 10):
                screen.blit(background, (0, 0))
            if game_count in range(11, 20):
                screen.blit(background2, (0, 0))
            if game_count > 21:
                game_count = 0

        win_font = pygame.font.Font('/Users/charlieyorke/ace/imgs/pokemon-gb-font.tff/pokemonfont.ttf', 50)
        win_font_n = win_font.render('WINNER: NARUTO', 1, (0, 0, 0))
        win_font_s = win_font.render('WINNER: SASUKE', 1, (0, 0, 0))

        if level.p1_winner == True:
            win_count += 1
            #print(win_count)
            screen.blit(win_font_n, (250, 350))
        if level.p2_winner == True:
            win_count += 1
            #print(win_count)
            if win_count < 200:
                screen.blit(win_font_s, (250, 350))
        

        if fight_count < 100:
            screen.blit(fight_symobl, (350, 250))
            level.running = False
        if fight_count in range(101, 150):
            level.running = True
        
        level.run()

def settings_page():
    
    run = True

    font = pygame.font.Font('/Users/charlieyorke/ace/imgs/pokemon-gb-font.tff/pokemonfont.ttf', 35)

    p1_font = font.render('Player 1 Controls:', 1,(255, 0, 0))
    p1_jump = font.render('Jump: W', 1, (255, 0, 0))
    p1_right = font.render('Right: D', 1, (255, 0, 0))
    p1_left = font.render('Left: A', 1, (255, 0, 0))
    p1_attack1_font = font.render('Attack 1: C', 1, (255, 0, 0))
    p1_attack2_font = font.render('Attack 2: X', 1, (255, 0, 0))

    p2_font = font.render('Player 2 Controls:', 1,(255, 0, 0))
    p2_jump = font.render('Jump: UP', 1, (255, 0, 0))
    p2_right = font.render('Right: RIGHT', 1, (255, 0, 0))
    p2_left = font.render('Left: LEFT', 1, (255, 0, 0))
    p2_attack1_font = font.render('Attack 1: M', 1, (255, 0, 0))
    p2_attack2_font = font.render('Attack 2: N', 1, (255, 0, 0))

    while run:
        screen.fill('black')
        screen.blit(p1_font, (200, 200))
        screen.blit(p1_jump, (200, 250))
        screen.blit(p1_right, (200, 300))
        screen.blit(p1_left, (200, 350))
        screen.blit(p1_attack1_font, (200, 400))
        screen.blit(p1_attack2_font, (200, 450))

        screen.blit(p2_font, (700, 200))
        screen.blit(p2_jump, (700, 250))
        screen.blit(p2_right, (700, 300))
        screen.blit(p2_left, (700, 350))
        screen.blit(p2_attack1_font, (700, 400))
        screen.blit(p2_attack2_font, (700, 450))

        back_button.draw()
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
            if event.type == pygame.MOUSEBUTTONDOWN and back_button.draw():
                main_menu()

def pause():
    
    paused = True

    font = pygame.font.SysFont("Comicsans", 40)

    #menu_button.draw()

    while paused:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()

            if menu_button.draw():
                main_menu()

            elif return_button.draw():
                paused = False
        
        pygame.draw.rect(screen, (255, 255, 255), (300, 176, 600, 352))
        menu_button.draw()
        return_button.draw()
        pygame.display.update()

def selecting_map():
    run = True
    while run:
        screen.blit(map_select_screen, (0, 0))
        map1_select.draw()
        map2_select.draw()
        
        pygame.display.update()

        if level.map1 == True:
            level.map2 = False
        if level.map2 == True:
            level.map2 = False

        for event in pygame.event.get():
            if event.type == MOUSEBUTTONDOWN and map1_select.draw():
                level.map1 = True
                level.map2 = False
                level.running = False
                level.reset()

def main_menu():
    run = True
    FPS = 75
    while run:
        screen.fill('black')
        start_button.draw()
        settings_button.draw()
        exit_button.draw()
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
            if event.type == pygame.MOUSEBUTTONDOWN and start_button.draw():
                selecting_map()
            if event.type == pygame.MOUSEBUTTONDOWN and settings_button.draw():
                settings_page()
            if event.type == pygame.MOUSEBUTTONDOWN and exit_button.draw():
                sys.exit()

    pygame.quit()
        
main_menu()