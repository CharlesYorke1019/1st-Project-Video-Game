import pygame
import sys

from support import import_folder

pygame.init()

screen_width = 1200
screen_height = 704
screen = pygame.display.set_mode((screen_width, screen_height))

clock = pygame.time.Clock()

class Player(pygame.sprite.Sprite):
    def __init__(self, name, pos):
        pygame.sprite.Sprite.__init__(self)
        self.import_character_assets()
        self.name = name
        self.frame_index = 0
        self.animation_speed = 0.15
        self.image = self.animations['idle'][self.frame_index]
        self.rect = self.image.get_rect(topleft = pos)

        self.direction = pygame.math.Vector2(0, 0)
        self.speed = 10
        self.gravity = 0.9
        self.jump_speed = -25

        self.status = 'idle'
        self.facing_right = True
        self.on_ground = True
        self.on_ceiling = False
        self.on_right = False
        self.on_left = False

        self.max_health = 320
        self.chakra = 234

        self.charge = 0
        self.super_level = 0
        self.super_attack = False

        self.cancellation = 2

        self.taking_damage = False

        self.attack1 = False
        self.attack2 = False

    def import_character_assets(self):
        character_path = '/Users/charlieyorke/ace/imgs/Naruto/'
        self.animations = {'idle': [], 'run': [], 'jump': [], 'attack': [], 'attack2': [], 'special': [], 'shield': [], 'combo': [], 'charge': []}

        for animation in self.animations.keys():
            full_path = character_path + animation
            self.animations[animation] = import_folder(full_path)

    def animate(self):
        animation = self.animations[self.status]

        # loop over frame index
        self.frame_index += self.animation_speed
        if self.frame_index >= len(animation):
            self.frame_index = 0

        image = animation[int(self.frame_index)]
        if self.facing_right:
            self.image = image
        else:
            flipped_image = pygame.transform.flip(image, True, False)
            self.image = flipped_image

        if self.on_ceiling:
            self.rect = self.image.get_rect(bottom = self.rect.bottom)
        elif self.on_ceiling:
            self.rect = self.image.get_rect(midtop = self.rect.midtop)
        else:
            self.rect = self.image.get_rect(center = self.rect.center)

    def get_input(self):
        keys = pygame.key.get_pressed()

        if keys[pygame.K_d] and self.rect.x < 1150:
            self.direction.x = 1
            self.facing_right = True
            
        elif keys[pygame.K_a] and self.rect.x > 1:
            self.direction.x = -1
            self.facing_right = False
        
        else:
            self.direction.x = 0

        if keys[pygame.K_w] and self.on_ground == True:
            if self.rect.bottom <= 698:
                self.on_ground = False
                self.jump()


    def get_status(self):

        run = True

        keys = pygame.key.get_pressed()

        if self.direction.y < 0:
            self.status = 'jump'
            self.animation_speed = .15
        
        else:
            if self.direction.x != 0:
                self.status = 'run'
                self.animation_speed = .15
            else:
                self.status = 'idle'
                self.animation_speed = .15

        if self.chakra > 15:

            if self.cancellation > 1:

                if keys[pygame.K_c]:
                    self.status = 'attack'
                    self.animation_speed = .20
                    self.direction.x = 0 
                    if self.on_ground == True:
                        self.direction.y = 0
                    self.chakra -= .55
                    if self.chakra == 0:
                        self.rect.y = self.rect.y
                

                if keys[pygame.K_x]:
                    self.status = 'attack2'
                    self.animation_speed = .20
                    self.direction.x = 0 
                    if self.on_ground == True:
                        self.direction.y = 0
                    self.chakra -= .55
                    if self.chakra == 0:
                        self.rect.y = self.rect.y
                    
        if keys[pygame.K_s]:
            self.status = 'charge'
            self.animation_speed = .60
            self.direction.x = 0
            if self.on_ground == True:
                self.direction.y = 0 
            self.charge += 3
            #print(self.charge)
            print(self.super_level)

        if keys[pygame.K_e] and self.super_level == 2:
            self.status = 'special'
            self.super_attack = True
            self.animation_speed = 1
            self.direction.x = 0
            if self.on_ground == True:
                self.direction.y = 0 

        if keys[pygame.K_z]:
            self.status = 'combo'
            self.animation_speed = .20
            if self.on_ground == True:
                self.direction.y = 0
        
    def apply_gravity(self):
        if self.on_ground == False:
            self.direction.y += self.gravity
            self.rect.y += self.direction.y

        
    def jump(self):
        self.direction.y = self.jump_speed

    def update(self):
        self.get_input()
        self.get_status()
        self.animate()

n_x = 100
n_y = 640
naruto = Player('Naruto', (n_x, n_y))
naruto_sprite = pygame.sprite.GroupSingle()
naruto_sprite.add(naruto)


def main():
    FPS = 60
    run = True
    
    while run:
        pygame.display.update()
        clock.tick(FPS)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                sys.exit()

        naruto_sprite.draw(screen)
        naruto.update()

main()